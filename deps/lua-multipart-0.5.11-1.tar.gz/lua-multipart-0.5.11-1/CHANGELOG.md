# Table of Contents

- [v0.5.11](#v0511)
- [v0.5.10](#v0510)
- [v0.5.9](#v059)

## [v0.5.11]

> Released 2025/08/05

### Fixes
- fix: remove parts from `get_all_include_headers_with_arrays()` headers

## [v0.5.10]

> Released 2025/07/28

### Features
- Add `get_all_include_headers_with_arrays()` function to get struct headers informations.

## [v0.5.9]

> Released 2020/07/23

### Fixes

- Fix issue where header matching pattern could take an indeterminate amount
of time on long strings.

[v0.5.9]: https://github.com/Kong/lua-multipart/compare/v0.5.8..v0.5.9
